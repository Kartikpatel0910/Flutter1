// import 'package:flutter/material.dart';
//
// ScaffoldFeatureController<SnackBar, SnackBarClosedReason> commonSnackBar({
//   required BuildContext context,
//   required String msg,
//   double? fontSize,
//   int? durationSeconds,
// }) {
//   return ScaffoldMessenger.of(context).showSnackBar(
//     SnackBar(
//       content: Text(msg, style: TextStyle(fontSize: fontSize ?? 15)),
//       duration: Duration(seconds: durationSeconds ?? 2),
//     ),
//   );
// }
