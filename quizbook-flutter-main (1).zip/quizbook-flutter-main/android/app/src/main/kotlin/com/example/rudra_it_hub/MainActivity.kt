package com.example.rudra_it_hub

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
