// const baseUrl = 'http://65.1.125.61:3000/';
// const baseUrl = 'http://65.1.125.61:3000/';
const baseUrl = 'https://quizbook-api.rudraithub.com/';

const loginUrl = 'users/login';
const signupUrl = 'users/signup';
const userVerifyUrl = 'user/varify';
const dashboardUrl = 'std';
const chapterUrl = 'std/subject/chapter';
const userProfileDataUrl = '65a0bec31e87d7a0656cf64f/profile';
const userProfileUpdateUrl = 'profile/update';
const uploadUserProfileUrl = 'users/avatars';
const userProfessionUrl = 'users/profession';
const resultUrl = 'results';
const historyUrl = 'history';
const questionUrl = 'std/subject/chapter/questions';
