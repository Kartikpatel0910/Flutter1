class Preferences {
  static const userLogin = "userLogin";
  static const token = "token";
  static const userID = "userID";
  static const id = "id";
  static const userFullDetails = "userFullDetails";
}
